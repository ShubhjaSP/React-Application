
import React from 'react'

export const RemovedItem = () => {
  return (
    <div>RemovedItem</div>
  )
}
