

// export const BASE_SERVER_URL="https://reqres.in";
// export const USERLIST=BASE_SERVER_URL+"/api/users";

// export const LOGIN_ENDPOINT=BASE_SERVER_URL+"/api/login";

// export const UPDATE_DATA=BASE_SERVER_URL+"/api/users/2";

// export const DELETE_DATA=BASE_SERVER_URL+"/api/users/2";


// export const USERLIST2="https://jsonplaceholder.typicode.com/users";

export const BASE_SERVER_URL="http://localhost:3000";
export const USERLIST=BASE_SERVER_URL+"/users";
export const SIGNUP=BASE_SERVER_URL+"/signup";
export const LOGIN_ENDPOINT=BASE_SERVER_URL+"/login";
export const REFRESH_TOKEN=BASE_SERVER_URL+"/refresh";
export const ARTLIST=BASE_SERVER_URL+"/showArts";
export const ADD_ART=BASE_SERVER_URL+"/addArt";


